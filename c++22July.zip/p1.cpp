#include<iostream>
using namespace std;
int main()
{
	
int a = 5;
int *ptr1;
int **ptr2;

ptr1 = &a;
ptr2 = &ptr1;


cout<<(&a)<<endl;//address of a;
cout<<ptr1<<endl;//address of a;
cout<<*ptr2<<endl;//address of a

cout<<&ptr1<<endl;//address of ptr1;
cout<<ptr2<<endl;//address of ptr1;


cout<<a<<endl;//value of a
cout<<*ptr1<<endl;//value of a
cout<<**ptr2<<endl;//value of a

}
