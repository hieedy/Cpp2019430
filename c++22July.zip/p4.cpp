#include<iostream>
using namespace std;
class test
{
	int a;
	public:
		test(int x)
		{
			a=x;
		}
	friend void sum(test t1, test t2);
};

void sum(test t1, test t2)
{
	cout<<(t1.a+t2.a);
}
int main()
{
	test t1(5),t2(10);
		sum(t1,t2);
}

