#include<iostream>
using namespace std;
int main()
{
	int a[5];
	int *ptr =a;
	
	for(int i=0;i<5;i++)
	{
		cin>>*(ptr+i);
	}
	
	cout<<"Your entered elements are shown below: "<<endl;
	for(int i=0;i<5;i++)
	{
		cout<<*(ptr+i);
	}
	
}
