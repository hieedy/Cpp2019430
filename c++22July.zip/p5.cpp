#include<iostream>
using namespace std;
class test2;
class test1
{
	int a;
	public:
		test1(int x)
		{
			a=x;
		}
	void sum(test2 t2);
};
class test2
{
	int b;
	public:
	test2(int y)
	{
		b=y;
	}
	friend void test1::sum(test2 t2);
};
void  test1::sum(test2 t2)
{
		cout<<(a+t2.b);
}
int main()
{
	test1 t1(5);
	test2 t2(10);
	t1.sum(t2);
}

