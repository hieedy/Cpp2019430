#include<iostream>
using namespace std;
class rectangle
{
	int length;
	int breadth;
	public:
		void read()
		{
			cout<<"Length: ";
			cin>>length;
			cout<<"Breadth: ";
			cin>>breadth;
		}
		void Area()
		{
			cout<<"Area is "<<(length*breadth);
		}
};
int main()
{
	rectangle *ptr;
	rectangle r1,r2;
	ptr = &r1;
	ptr->read();
	ptr->Area();
	
	ptr = &r2;
	ptr->read();
	ptr->Area();
}
