#include<iostream>
using namespace std;
class test
{
	public:
		test()
		{
			cout<<"object created "<<endl;
		}
		
		~test()
		{
			cout<<"object destroyed";
		}
};
int main()
{
	test *ptr = new test();
	delete ptr;
	cout<<"Inside main()";
	
}
