#include<iostream>
using namespace std;
class student
{
	string name;
	int roll;
	public:
		void read()
		{
			cout<<"Enter name ";
			cin>>name;
			cout<<"Roll: ";
			cin>>roll;
		}
		void display()
		{
			cout<<"Name is "<<name<<endl;
			cout<<"Roll is "<<roll<<endl;
			cout<<"_______________________________________________"<<endl;
		}
};
int main()
{
	int size;
	cout<<"Enter Number of Students: ";
	cin>>size;
		student *ptr = new student[size];
		
		for(int i=0;i<size;i++)
		{
			(ptr+i)->read();
		}
		for(int i=0;i<size;i++)
		{
			(ptr+i)->display();
		}
		
	delete[] ptr;	
}
