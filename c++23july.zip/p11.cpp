#include<iostream>
using namespace std;
class test
{
	int *a,*b;
	public:
		test()
		{
			a = new int(20);
			b = new int(30);
		}
		void show()
		{
			cout<<"a is "<<*a<<endl;
			cout<<"b is "<<*b<<endl;
		}
		~test()
		{
				delete a,b;			
		}
};
int main()
{
	test *t = new test();
	t->show();
	delete t;
}
