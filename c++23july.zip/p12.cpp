#include<iostream>
using namespace std;
class base
{
	protected: int a;
	public:
		base()
		{
			a=20;
		}
		void show()
		{
			cout<<"a is "<<a;
		}
};
class derived : public base
{
	int b;
	public:
		derived()
		{
			b=30;
		}
		void display()
		{
			cout<<a+b;
		}
};
int main()
{
	derived obj;
	base *ptr;
	ptr  = &obj; 
	ptr->show();
}
