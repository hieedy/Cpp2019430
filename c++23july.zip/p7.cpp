#include<iostream>
using namespace std;
class student
{
	string name;
	int roll;
	public:
		void read()
		{
			cout<<"Enter name ";
			cin>>name;
			cout<<"Roll: ";
			cin>>roll;
		}
		void display()
		{
			cout<<"Name is "<<name<<endl;
			cout<<"Roll is "<<roll<<endl;
			cout<<"_______________________________________________"<<endl;
		}
};
int main()
{
	student *ptr = new student();
	ptr->read();
	ptr->display();
	
}
