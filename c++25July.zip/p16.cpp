#include<iostream>
using namespace std;
class test
{
	public:
		~test()
		{
			cout<<"test class object destroyed";
		}
};
class exam:public test
{
	public:
		~exam()
		{
			cout<<"exam class object destroyed";
		}
};
int main()
{
	exam e;
	cout<<"inside main";
}
