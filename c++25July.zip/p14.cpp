#include<iostream>
using namespace std;
class test
{
	public:
		void display()
		{
			cout<<"Hello Base";
		}
};
class derived1: public test
{
	public:
		void display()
		{
			cout<<"Hello Derived 1"<<endl;
		}
};

class derived2:public test
{
	public:
		void display()
		{
			cout<<"Hello derived 2"<<endl;
		}
};
int main()
{
	test *ptr;
	derived1 obj1;
	derived2 obj2;
	ptr = &obj1;
	ptr->display();
	ptr = &obj2;
	ptr->display();
}
