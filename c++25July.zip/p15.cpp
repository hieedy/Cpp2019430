#include<iostream>
using namespace std;
class student
{
	int age;
	int rollno;
	string name;
	long long int mobile;
	public:
		student(int age, int rollno, string name, long long int mobile)
		{
			this.age=age;
			this->rollno = rollno;
			this->name= name;
			this->mobile=mobile;
		}
		void display()
		{
			cout<<"name is "<<this->name<<endl;
			cout<<"Age is "<<this->age<<endl;
			cout<<"rollno is "<<rollno<<endl;
			cout<<"mobile is "<<mobile<<endl;
		}
};
int main()
{
	student t(22,1100,"sourabh",9874563321);
	student d(23,1101,"Sahil",965478213);
	t.display();
	d.display();
}
