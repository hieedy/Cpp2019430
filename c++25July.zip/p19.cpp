#include<iostream>
using namespace std;
class base
{
	protected: int *a;
	public:
		base()
		{
			a = new int(20);
		}
		virtual void display()=0;
		virtual ~base()
		{
			cout<<"Base Class Memeory Free...."<<endl;
			delete a;
		}
};
class derived:public base
{
	int *b;
	public:
		derived()
		{
			b = new int(30);
		}
		void display()
		{
			cout<<"a is "<<*a<<"b is "<<*b<<endl;
		 } 
		~derived()
		{
			delete b;
			cout<<"Derived Class Memory Free.. "<<endl;
		}
};
int main()
{
	base *ptr = new derived();
	ptr->display();
	delete ptr;
}
