#include<iostream>
using namespace std;
class base
{
	protected: int *a;
	public:
		base()
		{
			a = new int(20);
		}
		void display()
		{
			cout<<"a is "<<a;
		}
		~base()
		{
			cout<<"Base Class Memeory Free....";
			delete a;
		}
};
class derived:public base
{
	int *b;
	public:
		derived()
		{
			b = new int(30);
		}
		void sum()
		{
			cout<<*a+*b;
		}
		~derived()
		{
			delete b;
			cout<<"Derived Class Memory Free.. ";
		}
};
int main()
{
	derived *d = new derived();
	d->sum();
	delete d;
}
