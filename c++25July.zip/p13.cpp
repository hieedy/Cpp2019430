#include<iostream>
using namespace std;
class test
{
	public:
		virtual void display()
		{
			cout<<"Hello everyone";
		}
};
class derived: public test
{
	public:
		void display()
		{
			cout<<"Hello Derived";
		}
};

int main()
{
	test *ptr;
	derived obj;
	ptr = &obj;
	ptr->display();
}
