#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ofstream fout("D:\\t1.txt",ios::app|ios::out);
	
	if(!fout)
	{
		cout<<"File is not opened";
	}
	else
	{
		string data;
		getline(cin,data,'$');
		fout<<data;
	}
	
}
