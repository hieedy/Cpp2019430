#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ifstream fin("D:\\file.txt");
	if(!fin)
	{
		cout<<"FIle cant be opened";
	}
	else
	{
		fin.seekg(0,ios::end);
		long long int size = fin.tellg();
		cout<<size;
		
	}
	
	fin.close();
}
