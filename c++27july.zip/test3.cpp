#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	fstream file("D:\\file.txt",ios::in|ios::out);
	
	if(!file)
	{
		cout<<"File cant be opened";
	}
	else
	{
		char ch;
		file.get(ch);
		static int count;
		
		while(file.eof()==0)
		{
			count++;
			file.get(ch);
		}
		cout<<count<<"bytes. ";
	}
	file.close();
	
}
