#include<iostream>
using namespace std;
int main()
{
	char ch;
	cin.get(ch);
	cout.put(ch);
}
