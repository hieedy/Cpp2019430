#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ifstream fin("D:\\t1.txt");
	ofstream fout("D:\\t2.txt");
	if(!fin)
	{
		cout<<"File is not opened";
	}
	else
	{
		
		string data;
		while(getline(fin,data)!=0)
		{
			fout<<data<<endl;
		}
	}
	
}
