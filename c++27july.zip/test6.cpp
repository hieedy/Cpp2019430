#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ifstream fin("D:\\file.txt",ios::binary);
	if(!fin)
	{
		cerr<<"File cannot be opened";
	}
	else
	{
		int x;
		fin.read((char *)&x,sizeof(x));
		cout<<x;
		fin.close();
			
	}
}
