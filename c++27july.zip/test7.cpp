#include<iostream>
#include<fstream>
using namespace std;
class student
{
	char name[100];
	int roll;
	public:
		void read()
		{
			cout<<"name: ";
			cin.getline(name,99);
			cout<<"Roll: ";
			cin>>roll;
		}
		void display()
		{
			cout<<"Name is "<<name<<endl;
			cout<<"Roll Is "<<roll<<endl;
		}
};
int main()
{
	ifstream fout("D:\\Student.txt");
	if(!fout)
	{
		cout<<"File cant be opened";
	}
	else
	{
		student s;
		fout.read((char *)&s,sizeof(s));
		s.display();
		fout.close();
	}
}
