#include<stdio.h>
int main()
{
    int num =265;
	while(num>=10)
	{
		num=num/10;//265
	}
	
	printf("%d is first digit",num);
	
	
	
	
	
	
	
}
