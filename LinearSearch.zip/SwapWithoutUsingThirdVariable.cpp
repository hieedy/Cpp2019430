/*
program to swap two numbers wihout using two variables...
Author : Sourabh Sharma
Date: 22-june-2019
*/
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int a=20;
	int b =30;
	cout<<"before swapping."<<endl;
	cout<<"a is "<<a<<endl;
	cout<<"b is "<<b<<endl;
	a = a+b;
	b = a-b;
	a = a-b;
	cout<<"After swapping"<<endl;
	cout<<"a is "<<a<<endl;
	cout<<"b is "<<b<<endl;
	getch();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
